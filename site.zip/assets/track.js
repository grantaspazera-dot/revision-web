/* REVISION LT – lengvas pirminis apsilankymų sekimas.
   sessionStorage (ne slapukai). Bet kokia klaida nutildoma ir svetainės neveikia. */
(function () {
  'use strict';

  var ENDPOINT = 'https://os.revision.lt/api/public/track';
  var SITE = 'revision.lt';
  var UTM_KEYS = ['utm_source', 'utm_campaign', 'utm_content'];
  var SS_UTM = 'rev_utm';
  var SS_SID = 'rev_session_id';

  var memorySid = '';
  var memoryUtm = null;
  var activeMs = 0;
  var visibleSince = 0;
  var lastLeaveSec = null;

  function guard(fn) {
    try {
      return fn();
    } catch (e) {
      return undefined;
    }
  }

  function storageGet(key) {
    return guard(function () {
      return window.sessionStorage.getItem(key);
    });
  }

  function storageSet(key, value) {
    guard(function () {
      window.sessionStorage.setItem(key, value);
    });
  }

  function emptyUtm() {
    return { utm_source: '', utm_campaign: '', utm_content: '' };
  }

  function pickUtm(source) {
    var out = emptyUtm();
    if (!source) return out;
    for (var i = 0; i < UTM_KEYS.length; i++) {
      var key = UTM_KEYS[i];
      var value = source[key];
      out[key] = value ? String(value) : '';
    }
    return out;
  }

  function readUrlUtms() {
    var params = guard(function () {
      return new URLSearchParams(window.location.search);
    });
    if (!params) return null;
    var found = false;
    var raw = {};
    for (var i = 0; i < UTM_KEYS.length; i++) {
      var key = UTM_KEYS[i];
      var value = params.get(key);
      if (value) {
        found = true;
        raw[key] = value;
      }
    }
    return found ? pickUtm(raw) : null;
  }

  function loadUtms() {
    if (memoryUtm) return memoryUtm;
    var fromUrl = readUrlUtms();
    if (fromUrl) {
      memoryUtm = fromUrl;
      storageSet(SS_UTM, JSON.stringify(fromUrl));
      return memoryUtm;
    }
    var saved = guard(function () {
      var raw = storageGet(SS_UTM);
      return raw ? JSON.parse(raw) : null;
    });
    memoryUtm = pickUtm(saved);
    return memoryUtm;
  }

  function fallbackId() {
    var time = Date.now().toString(16);
    var rand = Math.random().toString(16).slice(2);
    return time + '-' + rand;
  }

  function sessionId() {
    var existing = storageGet(SS_SID);
    if (existing) {
      memorySid = existing;
      return existing;
    }
    if (!memorySid) {
      memorySid = guard(function () {
        return window.crypto && crypto.randomUUID && crypto.randomUUID();
      }) || fallbackId();
      storageSet(SS_SID, memorySid);
    }
    return memorySid;
  }

  function pagePath() {
    return guard(function () {
      return window.location.pathname || '/';
    }) || '/';
  }

  function send(eventType, extra) {
    guard(function () {
      var utm = loadUtms();
      var payload = {
        session_id: sessionId(),
        site: SITE,
        event_type: eventType,
        page_path: pagePath(),
        page_title: document.title || '',
        utm_source: utm.utm_source || '',
        utm_campaign: utm.utm_campaign || '',
        utm_content: utm.utm_content || '',
        referrer: document.referrer || '',
        click_href: '',
        click_text: '',
        duration_sec: 0
      };
      if (extra) {
        for (var key in extra) {
          if (Object.prototype.hasOwnProperty.call(extra, key)) payload[key] = extra[key];
        }
      }
      var json = JSON.stringify(payload);
      var delivered = false;
      if (navigator.sendBeacon) {
        delivered = guard(function () {
          return navigator.sendBeacon(ENDPOINT, new Blob([json], { type: 'text/plain' }));
        }) === true;
      }
      if (!delivered && window.fetch) {
        fetch(ENDPOINT, {
          method: 'POST',
          body: json,
          headers: { 'Content-Type': 'text/plain' },
          keepalive: true,
          credentials: 'omit',
          mode: 'cors'
        }).catch(function () {});
      }
    });
  }

  function clickText(el) {
    var text = guard(function () {
      var visible = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      if (visible) return visible;
      var label = el.getAttribute('aria-label');
      if (label) return String(label).replace(/\s+/g, ' ').trim();
      var img = el.querySelector && el.querySelector('img[alt]');
      return img ? String(img.getAttribute('alt') || '').replace(/\s+/g, ' ').trim() : '';
    }) || '';
    if (text.length > 120) text = text.slice(0, 120);
    return text;
  }

  function onClick(event) {
    guard(function () {
      var node = event.target;
      if (!node || !node.closest) return;
      var el = node.closest('a, button');
      if (!el) return;
      var href = '';
      if (el.tagName === 'A') href = el.getAttribute('href') || el.href || '';
      send('click', { click_href: href, click_text: clickText(el) });
    });
  }

  function activeNow() {
    var extra = visibleSince ? Date.now() - visibleSince : 0;
    var total = activeMs + extra;
    if (!isFinite(total) || total < 0) return 0;
    return total;
  }

  function durationSec() {
    return Math.max(0, Math.round(activeNow() / 1000));
  }

  function pause() {
    if (!visibleSince) return;
    activeMs += Date.now() - visibleSince;
    visibleSince = 0;
  }

  function resume() {
    if (!visibleSince) visibleSince = Date.now();
  }

  function reportLeave() {
    guard(function () {
      var sec = durationSec();
      if (lastLeaveSec !== null && (sec === lastLeaveSec || sec === 0)) return;
      lastLeaveSec = sec;
      send('leave', { duration_sec: sec });
    });
  }

  guard(function () {
    if (document.visibilityState !== 'hidden') visibleSince = Date.now();
    loadUtms();
    sessionId();
    document.addEventListener('click', onClick, true);
    document.addEventListener('visibilitychange', function () {
      guard(function () {
        if (document.visibilityState === 'hidden') {
          pause();
          reportLeave();
        } else {
          resume();
        }
      });
    });
    window.addEventListener('pagehide', function () {
      guard(function () {
        pause();
        reportLeave();
      });
    });
    send('pageview');
  });
})();
