/* REVISION LT – trumpas inventorizacijos klausimynas.
   Siunčia JSON į os.revision.lt. UTM imami iš adreso arba sessionStorage (track.js). */
(function () {
  'use strict';

  var ENDPOINT = 'https://os.revision.lt/api/public/questionnaire';
  var UTM_KEYS = ['utm_source', 'utm_campaign', 'utm_content'];
  var form = document.getElementById('klausimynas');
  if (!form) return;

  var button = document.getElementById('klausimynas-submit');
  var statusBox = document.getElementById('klausimynas-status');
  var idleLabel = button ? button.textContent : 'Siųsti klausimyną';

  function val(id) {
    var el = document.getElementById(id);
    return el ? String(el.value || '').trim() : '';
  }

  function checkedValues(name) {
    var nodes = form.querySelectorAll('input[name="' + name + '"]:checked');
    var out = [];
    for (var i = 0; i < nodes.length; i++) out.push(nodes[i].value);
    return out;
  }

  function radioValue(name) {
    var node = form.querySelector('input[name="' + name + '"]:checked');
    return node ? node.value : '';
  }

  function readUtms() {
    var out = { utm_source: '', utm_campaign: '', utm_content: '' };
    try {
      var params = new URLSearchParams(window.location.search);
      var fromUrl = false;
      for (var i = 0; i < UTM_KEYS.length; i++) {
        var key = UTM_KEYS[i];
        var value = params.get(key);
        if (value) {
          fromUrl = true;
          out[key] = value;
        }
      }
      if (fromUrl) return out;
      var raw = window.sessionStorage.getItem('rev_utm');
      if (!raw) return out;
      var saved = JSON.parse(raw);
      for (var j = 0; j < UTM_KEYS.length; j++) {
        var savedKey = UTM_KEYS[j];
        out[savedKey] = saved && saved[savedKey] ? String(saved[savedKey]) : '';
      }
    } catch (e) {}
    return out;
  }

  function showStatus(kind, html) {
    if (!statusBox) return;
    statusBox.hidden = false;
    statusBox.className = 'kq-status ' + (kind === 'ok' ? 'kq-status-ok' : 'kq-status-err');
    statusBox.setAttribute('role', kind === 'ok' ? 'status' : 'alert');
    statusBox.innerHTML = html;
    if (statusBox.focus) statusBox.focus();
  }

  function hideStatus() {
    if (!statusBox) return;
    statusBox.hidden = true;
    statusBox.innerHTML = '';
  }

  function setBusy(busy) {
    if (!button) return;
    button.disabled = busy;
    button.textContent = busy ? 'Siunčiama…' : idleLabel;
    button.setAttribute('aria-busy', busy ? 'true' : 'false');
    form.setAttribute('aria-busy', busy ? 'true' : 'false');
  }

  function payload() {
    var utm = readUtms();
    return {
      company: val('company'),
      contact_name: val('contact_name'),
      email: val('email'),
      phone: val('phone'),
      city: val('city'),
      items_to_count: checkedValues('items_to_count'),
      approx_positions: val('approx_positions'),
      devices_count: val('devices_count'),
      devices_source: radioValue('devices_source'),
      plan_interest: radioValue('plan_interest'),
      preferred_date: val('preferred_date'),
      comment: val('comment'),
      website_hp: val('website_hp'),
      utm_source: utm.utm_source,
      utm_campaign: utm.utm_campaign,
      utm_content: utm.utm_content
    };
  }

  function successHtml() {
    return '<p><strong>Ačiū! Jūsų klausimynas gautas ir išsiųstas į <a href="mailto:grantas@revision.lt">grantas@revision.lt</a> — susisieksime artimiausiu metu.</strong></p>';
  }

  function errorHtml() {
    return '<p><strong>Nepavyko išsiųsti klausimyno.</strong> Patikrinkite interneto ryšį ir bandykite dar kartą arba parašykite tiesiai adresu <a href="mailto:grantas@revision.lt">grantas@revision.lt</a>.</p>';
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    hideStatus();
    if (typeof form.reportValidity === 'function' && !form.reportValidity()) return;

    var data = payload();
    if (data.website_hp) {
      form.reset();
      showStatus('ok', successHtml());
      return;
    }

    setBusy(true);
    var json = JSON.stringify(data);
    fetch(ENDPOINT, {
      method: 'POST',
      body: json,
      headers: { 'Content-Type': 'text/plain' },
      credentials: 'omit',
      mode: 'cors'
    }).then(function (response) {
      if (!response.ok) throw new Error('status');
      form.reset();
      showStatus('ok', successHtml());
    }).catch(function () {
      showStatus('err', errorHtml());
    }).then(function () {
      setBusy(false);
    });
  });
})();
