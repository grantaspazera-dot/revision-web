/* REVISION LT – užklausos forma „Kuo galime jums padėti?“.
   Pateikiama per https://forma.revision.lt/send.php (UAB Bacloud serveris): laiškas info@revision.lt ir patvirtinimas klientui.
   Nepavykus – atsarginis variantas: paruoštas el. laiškas (mailto). Jokių slapukų ar naršyklės saugyklos. */
(function(){
'use strict';
var KITA='__kita',NEZ='__nezinau';
function Q(id,title,multi,opts,x){var q={id:id,title:title,multi:multi,opts:opts};if(x)for(var k in x)q[k]=x[k];return q;}
var V=true,S=false; /* V – keli pasirinkimai, S – vienas */

var DIRS=[
 {key:'konsultacija',title:'Konsultacija',desc:'Sandėlio procesai ir valdymas',cat:'Pagrindinė',goal:'nustatyti sandėlio valdymo problemas, konsultacijos apimtį ir laukiamą rezultatą',qs:[
  Q('K1','Kokia pagrindinė jūsų įmonės veikla?',S,['Gamyba','Didmeninė prekyba','Mažmeninė prekyba','Logistika ir sandėliavimo paslaugos (3PL)','Kita paslaugų ar veiklos sritis']),
  Q('K2','Kokias sandėlio problemas norite išspręsti?',V,['Netikslūs prekių ar atsargų likučiai','Neefektyvus prekių išdėstymas ir lokacijų valdymas','Lėtas prekių priėmimas, surinkimas ar išdavimas','Neaiškios darbuotojų atsakomybės ir darbo procesai','Nepakankama apskaitos, barkodų ar sandėlio sistemų kontrolė'],{req:true}),
  Q('K3','Kokios apimties sandėlio veiklą reikia įvertinti?',S,['Vieną nedidelį sandėlį','Vieną didelį sandėlį','Kelis sandėlius vienoje teritorijoje','Kelis sandėlius skirtingose vietovėse','Visos įmonės atsargų valdymą']),
  Q('K4','Kaip šiuo metu valdote sandėlio procesus?',V,['ERP arba buhalterinės apskaitos sistema','Specializuota WMS sistema','Excel ar kitos skaičiuoklės','Popieriniai dokumentai ir rankinė apskaita','Kelios tarpusavyje susijusios sistemos']),
  Q('K5','Kokia jūsų sandėlio procesų organizavimo būklė?',S,['Procesai dokumentuoti ir nuosekliai vykdomi','Procesai dokumentuoti, bet ne visada jų laikomasi','Procesai veikia, tačiau nėra aiškiai aprašyti','Procesai skiriasi priklausomai nuo darbuotojo','Sandėlio procesai dar tik kuriami arba keičiami']),
  Q('K6','Kokio konsultacijos rezultato tikitės?',V,['Dabartinės situacijos ir problemų analizės','Konkrečių sandėlio valdymo rekomendacijų','Procesų optimizavimo veiksmų plano','Pagalbos diegiant numatytus pakeitimus','Darbuotojų apmokymo ir rezultatų kontrolės']),
  Q('K7','Kokio konsultavimo būdo pageidaujate?',S,['Vienkartinės konsultacijos nuotoliu','Vienkartinio apsilankymo sandėlyje','Išsamios analizės su apsilankymu vietoje','Kelių konsultacijų skirtingais etapais','Ilgalaikio konsultavimo ir procesų priežiūros'])]},
 {key:'auditas',title:'Auditas',desc:'Procesų ir atsargų kontrolės vertinimas',cat:'Pagrindinė',goal:'nustatyti audito objektą, rizikas, tikrinimo apimtį ir pageidaujamus rezultatus',qs:[
  Q('A1','Kokį auditą norėtumėte atlikti?',V,['Sandėlio valdymo procesų auditą','Atsargų apskaitos tikslumo auditą','Sandėlio lokacijų ir prekių identifikavimo auditą','Prekių judėjimo ir vidaus kontrolės auditą','Inventorizacijos organizavimo ir rezultatų auditą'],{req:true}),
  Q('A2','Kokia pagrindinė audito priežastis?',V,['Pasikartojantys atsargų neatitikimai','Įtarimai dėl sandėlio procesų neefektyvumo','Nepakankama atsargų kontrolė ir atsekamumas','Planuojama sandėlio pertvarka ar sistemų keitimas','Nepriklausomo įvertinimo poreikis vadovybei']),
  Q('A3','Kokią sandėlio veiklos dalį reikia audituoti?',S,['Visą sandėlio veiklą','Tik prekių priėmimą','Tik sandėliavimą ir lokacijų valdymą','Tik prekių surinkimą ir išdavimą','Tik atsargų apskaitą ir inventorizaciją']),
  Q('A4','Kokios problemos jau nustatytos?',V,['Prekių trūkumai arba perteklius','Prekės laikomos neteisingose lokacijose','Neužtikrinamas prekių judėjimo atsekamumas','Apskaitos informacija neatitinka faktinės situacijos','Problemų nenustatyta – reikalingas prevencinis auditas']),
  Q('A5','Kokius duomenis galėtumėte pateikti auditui?',V,['Prekių nomenklatūrą','Buhalterinius atsargų likučius','Sandėlio lokacijų sąrašą arba planą','Ankstesnių inventorizacijų rezultatus','Sandėlio procesų aprašus ir dokumentus']),
  Q('A6','Kokio audito detalumo pageidaujate?',S,['Pirminio ekspertinio įvertinimo','Pasirinktų procesų patikrinimo','Išsamaus sandėlio procesų audito','Audito su papildomu faktiniu prekių patikrinimu','Pakartotinio audito po atliktų pakeitimų']),
  Q('A7','Kokio rezultato tikitės po audito?',V,['Nustatytų problemų ir neatitikimų sąrašo','Rizikų įvertinimo','Procesų optimizavimo rekomendacijų','Prioritetinio veiksmų plano','Rezultatų pristatymo vadovybei ir aptarimo'])]},
 {key:'inventorizacija',title:'Inventorizacija',desc:'Prekės, atsargos ir ilgalaikis turtas',cat:'Papildoma',goal:'nustatyti inventorizacijos apimtį, technologinį pasirengimą ir reikalingus REVISION resursus',qs:[
  Q('I1','Kokį turtą ar atsargas reikia inventorizuoti?',V,['Prekes, skirtas pardavimui','Žaliavas ir gamybos medžiagas','Nebaigtą gamybą','Pagamintą produkciją','Ilgalaikį materialųjį turtą'],{req:true}),
  Q('I2','Koks preliminarus inventorizuojamų skirtingų pozicijų skaičius?',S,['Iki 500 pozicijų','501–2 000 pozicijų','2 001–10 000 pozicijų','10 001–50 000 pozicijų','Daugiau kaip 50 000 pozicijų'],{extras:[{id:'vnt',label:'Preliminarus fizinių vienetų skaičius, jei žinomas'}]}),
  Q('I3','Kokios apimties inventorizaciją planuojate?',S,['Vienas sandėlis','Keli sandėliai vienoje teritorijoje','Keli sandėliai skirtinguose miestuose','Parduotuvė arba prekybos padalinys','Keli padaliniai ar visas įmonės tinklas']),
  Q('I4','Kaip pažymėtos inventorizuojamos prekės arba turtas?',S,['Visos pozicijos turi skenuojamus barkodus','Dauguma pozicijų turi barkodus','Tik dalis pozicijų turi barkodus','Barkodų nėra – naudojami vidiniai kodai ar pavadinimai','Reikalingas papildomas prekių arba turto žymėjimas']),
  Q('I5','Kaip organizuotos sandėliavimo lokacijos?',S,['Visos lokacijos identifikuotos ir pažymėtos','Lokacijos nustatytos, bet ne visos pažymėtos','Naudojamos tik bendros sandėlio zonos','Lokacijų sistema nenaudojama','Lokacijų sistemą planuojama sukurti']),
  Q('I6','Kokio REVISION dalyvavimo pageidaujate?',V,['Inventorizacijos vadovo ir proceso koordinavimo','Inventorizacijos vadovo bei nepriklausomų skaičiavimo ekspertų','Nepriklausomo pasirinktinio lokacijų ar prekių perpatikrinimo','Inventorizacijos programos ir skenerių nuomos','Darbuotojų apmokymo ir konsultavimo']),
  Q('I7','Kaip apskaitomi inventorizuojami likučiai?',S,['Buhalterinėje arba ERP sistemoje, su Excel eksportu','WMS sistemoje, su Excel eksportu','Keliose apskaitos sistemose','Excel failuose','Duomenis reikės papildomai paruošti ar sutvarkyti']),
  Q('I8','Kada ir kokiomis sąlygomis numatyta inventorizacija?',V,['Darbo dienomis, įprastu darbo laiku','Vakare','Savaitgaliais','Sustabdžius sandėlio operacijas','Nenutraukiant įprastos sandėlio veiklos'],{extras:[{id:'data',label:'Inventorizacijos data'},{id:'adresas',label:'Tikslus adresas'},{id:'trukme',label:'Pageidaujama trukmė'},{id:'terminas',label:'Rezultato pateikimo terminas'}]})]},
 {key:'mokymai',title:'Mokymai',desc:'Darbuotojų kompetencijos',cat:'Papildoma',goal:'parinkti mokymų temą, dalyvius, praktinę apimtį ir formatą',qs:[
  Q('M1','Kokia mokymų tema aktuali jūsų įmonei?',V,['Inventorizacijos organizavimas ir vykdymas','Sandėlio valdymo procesai ir optimizavimas','Prekių ir atsargų apskaitos kontrolė','Barkodų ir lokacijų valdymas','REVISION ONLINE programos ir kaupiklių naudojimas'],{req:true}),
  Q('M2','Kam skirti mokymai?',V,['Sandėlio darbuotojams','Sandėlio vadovams','Inventorizacijos komandos nariams','Buhalterijos ir apskaitos darbuotojams','Įmonės vadovams ir procesų atsakingiesiems']),
  Q('M3','Kiek darbuotojų dalyvaus mokymuose?',S,['1–3 darbuotojai','4–6 darbuotojai','7–10 darbuotojų','11–20 darbuotojų','Daugiau kaip 20 darbuotojų']),
  Q('M4','Koks dalyvių pasirengimo lygis?',S,['Neturi patirties šioje srityje','Turi minimalių teorinių žinių','Turi praktinės darbo patirties','Patyrę specialistai, kuriems reikia gilinti kompetenciją','Mišri skirtingos patirties darbuotojų grupė']),
  Q('M5','Kokio pobūdžio mokymų pageidaujate?',S,['Teorinės konsultacijos su pavyzdžiais','Praktinių mokymų sandėlyje','Mokymų naudojant skenerius ir programinę įrangą','Kombinuotų teorinių ir praktinių mokymų','Individualių mokymų vadovams ar atsakingiems darbuotojams']),
  Q('M6','Kokios mokymų trukmės pageidaujate?',S,['Iki 2 valandų','3 valandų','4–5 valandų','Vienos darbo dienos','Kelių dienų mokymų programos']),
  Q('M7','Kokio rezultato tikitės po mokymų?',V,['Geresnio darbuotojų supratimo apie procesus','Mažesnio skaičiavimo ir duomenų registravimo klaidų skaičiaus','Savarankiško darbo su programa ir skeneriais','Vienodų darbo metodų taikymo komandoje','Pasirengimo inventorizacijai ar sandėlio pokyčiams']),
  Q('M8','Kur pageidaujate organizuoti mokymus?',S,['Mūsų įmonės sandėlyje','Mūsų įmonės biure','Nuotoliniu būdu','Derinant nuotolinius ir kontaktinius mokymus','Vieta bus nustatyta vėliau'])]},
 {key:'iranga',title:'Įranga',desc:'Zebra kaupikliai ir kita įranga',cat:'Papildoma',goal:'nustatyti reikiamos įrangos tipą, kiekį, naudojimo aplinką ir nuomos laikotarpį',qs:[
  Q('E1','Kokiems darbams reikalinga įranga?',V,['Prekių inventorizacijai','Ilgalaikio turto inventorizacijai','Kasdieniam prekių barkodų nuskaitymui','Sandėlio lokacijų identifikavimui','Etikečių spausdinimui ir turto ar prekių žymėjimui'],{req:true}),
  Q('E2','Kokios įrangos reikia?',V,['Zebra mobiliųjų duomenų kaupiklių','Android įrenginių su inventorizacijos programa','Barkodų etikečių spausdintuvo','Svarstyklių','Kelių rūšių įrangos komplekto']),
  Q('E3','Kiek įrangos vienetų planuojate naudoti?',S,['1 įrenginį','2–3 įrenginius','4–5 įrenginius','6–10 įrenginių','Daugiau kaip 10 įrenginių']),
  Q('E4','Kiek laiko reikės įrangos?',S,['Vienai dienai','2–3 dienoms','4–7 dienoms','8–30 dienų','Ilgesniam nei 30 dienų laikotarpiui']),
  Q('E5','Kokioje aplinkoje bus naudojama įranga?',V,['Įprastame uždarame sandėlyje','Gamybinėse patalpose','Prekybos salėje arba parduotuvėje','Lauko sandėliavimo teritorijoje','Keliose skirtingose darbo aplinkose']),
  Q('E6','Su kokia programine sistema naudosite įrangą?',S,['REVISION ONLINE ir Android APP','Savo įmonės ERP sistema','Savo įmonės WMS sistema','Kita inventorizacijos programa','Programa dar nepasirinkta']),
  Q('E7','Kokių papildomų paslaugų reikia?',V,['Įrangos paruošimo naudojimui','Programos įdiegimo arba konfigūravimo','Darbuotojų apmokymo','Pagalbos pradedant inventorizaciją','Tik įrangos nuomos be papildomų paslaugų'])]},
 {key:'programa',title:'Programa',desc:'REVISION ONLINE ir Android APP',cat:'Papildoma',goal:'nustatyti REVISION ONLINE ir Android APP naudojimo poreikį, duomenų struktūrą ir techninį pasirengimą',qs:[
  Q('P1','Kokiam darbui reikalinga programa?',V,['Prekių inventorizacijai','Žaliavų ir gamybos atsargų inventorizacijai','Pagamintos produkcijos inventorizacijai','Ilgalaikio turto inventorizacijai','Periodinėms arba pakartotinėms inventorizacijoms'],{req:true}),
  Q('P2','Kiek inventorizacijų planuojate atlikti?',S,['Vieną inventorizaciją','2–3 inventorizacijas per metus','4–6 inventorizacijas per metus','7–12 inventorizacijų per metus','Daugiau kaip 12 inventorizacijų per metus']),
  Q('P3','Kiek žmonių vienu metu naudosis programa?',S,['Vienas naudotojas','2–3 naudotojai','4–5 naudotojai','6–10 naudotojų','Daugiau kaip 10 naudotojų']),
  Q('P4','Kiek skirtingų prekių ar turto pozicijų planuojate inventorizuoti?',S,['Iki 500','501–2 000','2 001–10 000','10 001–50 000','Daugiau kaip 50 000']),
  Q('P5','Kokius pradinius duomenis galite pateikti?',V,['Prekių arba turto nomenklatūrą Excel formatu','Buhalterinius likučius Excel formatu','Prekių ar turto barkodų sąrašą','Sandėlio lokacijų informaciją','Šiuo metu duomenis dar reikės paruošti']),
  Q('P6','Kokius įrenginius planuojate naudoti?',V,['REVISION nuomojamus Zebra kaupiklius','Savo Zebra Android kaupiklius','Kitus Android kaupiklius','Android telefonus','Įrenginių dar neturime']),
  Q('P7','Kaip planuojate naudoti programą?',V,['Skenuoti barkodus ir registruoti kiekius','Inventorizuoti pagal sandėlio lokacijas','Naudoti kelis inventorizacijos vykdytojus','Dirbti su Android APP neprisijungus prie interneto ir vėliau sinchronizuoti duomenis','Eksportuoti rezultatus į Excel']),
  Q('P8','Kokios pagalbos reikės pradedant naudotis programa?',V,['Tik programos prieigos','Programos pristatymo ir demonstracijos','Nomenklatūros bei likučių importo paruošimo','Darbuotojų mokymų','Programos, kaupiklių ir pradinių konsultacijų komplekto'])]}
];
var B5MAP=['konsultacija','auditas','inventorizacija','mokymai','iranga|programa'];
var SHARED=[
 Q('B1','Kokia jūsų įmonės veiklos sritis?',S,['Gamyba','Didmeninė prekyba','Mažmeninė prekyba','Logistika ir sandėliavimo paslaugos','Kita paslaugų arba veiklos sritis']),
 Q('B2','Kur bus teikiama paslauga?',S,['Kaune arba Kauno regione','Vilniuje arba Vilniaus regione','Klaipėdoje arba Klaipėdos regione','Kitoje Lietuvos vietovėje','Latvijoje arba Estijoje'],{req:true,extras:[{id:'miestas',label:'Miestas ir, jei aktualu, objekto adresas'}]}),
 Q('B3','Kada reikalinga paslauga?',S,['Kuo greičiau','Per artimiausias 7 dienas','Per 2–4 savaites','Per 1–3 mėnesius','Tik planuojame ir renkame informaciją'],{req:true}),
 Q('B4','Kokios pagalbos apimties pageidaujate?',S,['Trumpalaikės ekspertinės konsultacijos','Vienkartinės paslaugos konkrečiai užduočiai','Kelių etapų projekto','Sprendimo su programa arba įranga','Ilgalaikio bendradarbiavimo']),
 Q('B5','Ar papildomai reikalingos kitos REVISION paslaugos?',V,['Konsultacija','Auditas','Inventorizacija','Mokymai','Įranga arba programa']),
 Q('B6','Kaip pageidaujate tęsti bendravimą?',S,['Gauti pirminį komercinį pasiūlymą el. paštu','Susisiekti telefonu ir aptarti poreikį','Organizuoti nuotolinį susitikimą','Organizuoti apsilankymą mūsų įmonėje','Gauti papildomą informaciją apie paslaugas'],{req:true}),
 Q('B7','Koks jūsų vaidmuo įmonėje?',S,['Įmonės vadovas arba savininkas','Sandėlio arba logistikos vadovas','Gamybos vadovas','Finansų arba apskaitos atstovas','Pirkimų, IT arba kito padalinio atstovas'])
];
var ALLQ={};DIRS.forEach(function(d){d.qs.forEach(function(q){ALLQ[q.id]=q;q.dir=d.key;});});SHARED.forEach(function(q){ALLQ[q.id]=q;});
function dirObj(k){for(var i=0;i<DIRS.length;i++)if(DIRS[i].key===k)return DIRS[i];return null;}

var state={dir:'',pos:0,ans:{},contact:{company:'',name:'',email:'',phone:'',comment:'',marketing:false},returnToSummary:false};
function resetAns(id){var q=ALLQ[id],e={};(q.extras||[]).forEach(function(x){e[x.id]='';});state.ans[id]={values:[],other:'',extra:e};}
Object.keys(ALLQ).forEach(resetAns);

function steps(){
  var s=[{id:'dir',stage:1,short:'Kryptis',title:'Pasirinkite pagrindinę kryptį',hint:'Pasirinkite vieną pagrindinę kryptį. Kitas paslaugas galėsite pažymėti vėliau. Nežinote? Rinkitės „Konsultacija“.',dir:true}];
  var d=dirObj(state.dir);
  if(d)d.qs.forEach(function(q,i){s.push({id:q.id,stage:2,short:q.id+'. '+d.title,title:q.title,hint:(q.multi?'Galite pažymėti kelis.':'Pasirinkite vieną.')+(q.req?'':' Nebūtina – galite praleisti.'),qs:[q],qi:i+1,qn:d.qs.length});});
  else s.push({id:'_need',stage:2,short:'Poreikis',title:'',qs:[]});
  var proj=SHARED.slice(0,3).filter(function(q){return !(q.id==='B1'&&state.dir==='konsultacija');});
  s.push({id:'proj',stage:3,short:'Projektas',title:'Projektas',hint:'Laukai su * privalomi, kiti – nebūtini.',qs:proj});
  s.push({id:'coop',stage:3,short:'Bendradarbiavimas',title:'Bendradarbiavimas',hint:'Laukai su * privalomi, kiti – nebūtini.',qs:SHARED.slice(3)});
  s.push({id:'contact',stage:3,short:'Kontaktai',title:'Kontaktai',hint:'Pakanka el. pašto arba telefono. Nurodžius el. paštą, atsiųsime užklausos gavimo patvirtinimą.',contact:true});
  s.push({id:'summary',stage:4,short:'Patvirtinimas',title:'Patikrinkite užklausą',hint:'Prieš patvirtindami galite pataisyti bet kurį atsakymą.',summary:true});
  return s;
}
function cur(){return steps()[state.pos];}
function b5opts(){return SHARED[4].opts.map(function(l,i){return {l:l,i:i};}).filter(function(o){return B5MAP[o.i].split('|').indexOf(state.dir)<0;});}

var host=document.getElementById('step-host'),form=document.getElementById('enquiry'),btnBack=document.getElementById('btn-back'),btnNext=document.getElementById('btn-next'),
    errSum=document.getElementById('err-summary'),done=document.getElementById('done'),pFill=document.getElementById('progress-fill'),pBar=document.getElementById('progressbar'),
    pLabel=document.getElementById('progress-label'),pPct=document.getElementById('progress-pct'),aside=document.getElementById('aside-steps');
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}

var STAGES=['Kryptis','Poreikis','Projektas ir kontaktai','Patvirtinimas'];
function renderAside(){
  var st=state.pos>=steps().length?5:cur().stage;
  aside.innerHTML=STAGES.map(function(n,i){var k=i+1,c=k<st?'done':(k===st?'current':'');return '<li class="'+c+'"'+(k===st?' aria-current="step"':'')+'>'+(k)+'. '+esc(n)+(k===2&&dirObj(state.dir)?' <small>('+esc(dirObj(state.dir).title)+')</small>':'')+'</li>';}).join('');
}
function renderProgress(){
  var all=steps(),n=all.length,s=cur(),pct=Math.round(state.pos/(n-1)*100);
  pFill.style.width=pct+'%';pBar.setAttribute('aria-valuenow',pct);
  var t=s.stage+' etapas iš 4 · '+STAGES[s.stage-1];
  if(s.qi)t+=' · klausimas '+s.qi+' iš '+s.qn;
  pLabel.textContent=t;pPct.textContent=pct+' %';
}
function optList(q){
  var list=(q.id==='B5'?b5opts():q.opts.map(function(l,i){return {l:l,i:i};}));
  return list.map(function(o){return {label:o.l,value:o.l,idx:o.i};}).concat([{label:'Kita (įrašykite)',value:KITA,idx:5},{label:'Nežinau',value:NEZ,idx:6,exclusive:true,cls:'opt-nez'}]);
}
function qHTML(q,single){
  var a=state.ans[q.id],type=q.multi?'checkbox':'radio';
  var h='<fieldset data-field="'+q.id+'"><legend'+(single?' class="sr-only"':'')+'>'+esc(q.title)+(q.req?' <span class="req" aria-hidden="true">*</span>':'')+(single?'':' <span class="counter-hint">('+(q.multi?'galima kelis':'vienas')+(q.req?'':', nebūtina')+')</span>')+'</legend><div class="opts">';
  optList(q).forEach(function(op){var id=q.id+'-'+op.idx;
    h+='<div class="opt'+(op.cls?' '+op.cls:'')+'"><input type="'+type+'" id="'+id+'" name="'+q.id+'" value="'+esc(op.value)+'"'+(a.values.indexOf(op.value)>-1?' checked':'')+(op.exclusive&&q.multi?' data-exclusive="1"':'')+'><label for="'+id+'"><span>'+esc(op.label)+'</span></label></div>';});
  h+='</div><div class="other-wrap"'+(a.values.indexOf(KITA)>-1?'':' hidden')+'><label class="sr-only" for="'+q.id+'-other">Jūsų atsakymas: '+esc(q.title)+'</label><input type="text" id="'+q.id+'-other" data-other="'+q.id+'" maxlength="200" placeholder="Įrašykite savo atsakymą" value="'+esc(a.other)+'" aria-describedby="'+q.id+'-err"></div>';
  (q.extras||[]).forEach(function(x){h+='<div class="field extra"><label for="'+q.id+'-x-'+x.id+'">'+esc(x.label)+' <span class="counter-hint">(nebūtina)</span></label><input type="text" id="'+q.id+'-x-'+x.id+'" data-extra="'+q.id+'" data-key="'+x.id+'" maxlength="200" value="'+esc(a.extra[x.id]||'')+'"></div>';});
  return h+'<div class="err" id="'+q.id+'-err" aria-live="polite"></div></fieldset>';
}
function dirHTML(){
  var h='<fieldset data-field="dir"><legend class="sr-only">Pagrindinė kryptis</legend><div class="opts dir-opts">';
  DIRS.forEach(function(d,i){h+='<div class="opt"><input type="radio" id="dir-'+i+'" name="dir" value="'+d.key+'"'+(state.dir===d.key?' checked':'')+'><label for="dir-'+i+'"><span><b>'+esc(d.title)+'</b><small>'+esc(d.desc)+' · '+esc(d.cat)+'</small></span></label></div>';});
  return h+'</div><div class="err" id="dir-err" aria-live="polite"></div></fieldset>';
}
function contactHTML(){
  var c=state.contact;
  function inp(id,label,type,val,auto,req,hint){return '<div class="field"><label for="c-'+id+'">'+label+(req?' <span class="req" aria-hidden="true">*</span>':'')+'</label><input type="'+type+'" id="c-'+id+'" name="'+id+'" value="'+esc(val)+'" autocomplete="'+auto+'"'+(req?' required aria-required="true"':'')+' aria-describedby="c-'+id+'-err'+(hint?' c-'+id+'-hint':'')+'">'+(hint?'<div class="counter-hint" id="c-'+id+'-hint">'+hint+'</div>':'')+'<div class="err" id="c-'+id+'-err"></div></div>';}
  var h='<p class="counter-hint">Laukai su <span class="req">*</span> privalomi.</p><div class="contact-grid">'+inp('company','Įmonės pavadinimas','text',c.company,'organization',1)+inp('name','Vardas ir pavardė','text',c.name,'name',1)+'</div>';
  h+='<div class="either" role="group" aria-labelledby="either-t" aria-describedby="either-err"><p id="either-t">Kaip su jumis susisiekti? Nurodykite bent vieną <span class="req" aria-hidden="true">*</span></p><div class="contact-grid">'+
     inp('email','Darbinis el. paštas','email',c.email,'email',0)+inp('phone','Telefonas','tel',c.phone,'tel',0,'Pvz., +370 612 34567 arba 8 612 34567')+'</div><div class="err" id="either-err"></div><div class="err" id="method-err"></div></div>';
  h+='<div class="field"><label for="c-comment">Papildomas komentaras <span class="counter-hint">(nebūtina)</span></label><textarea id="c-comment" name="comment" maxlength="1000">'+esc(c.comment)+'</textarea></div>';
  h+='<p class="privacy-note">Jūsų duomenis REVISION LT naudos tik atsakyti į šią užklausą ir parengti pasiūlymą. Plačiau – <a href="privatumas.html" target="_blank" rel="noopener">privatumo politikoje</a> (atsidarys naujame lange).</p>';
  h+='<div class="field"><div class="consent"><input type="checkbox" id="c-marketing" name="marketing"'+(c.marketing?' checked':'')+'><label for="c-marketing" style="font-weight:400">Sutinku gauti REVISION LT naujienas ir pasiūlymus el. paštu. <span class="counter-hint">(nebūtina, galima atšaukti bet kada)</span></label></div></div>';
  return h;
}
function ansText(id){var a=state.ans[id];if(!a.values.length)return null;return a.values.map(function(v){return v===KITA?('Kita: '+a.other):(v===NEZ?'Nežinau':v);}).join('; ')+Object.keys(a.extra).filter(function(k){return a.extra[k].trim();}).map(function(k){var x=(ALLQ[id].extras||[]).filter(function(e){return e.id===k;})[0];return ' · '+x.label+': '+a.extra[k].trim();}).join('');}
function summaryHTML(){
  var d=dirObj(state.dir),h='<ul class="summary-list">';
  function row(id,q,txt,edit){return '<li><span class="q">'+q+'</span><span class="a">'+txt+'</span><button type="button" class="linklike" data-edit="'+edit+'" aria-label="Taisyti: '+esc(q.replace(/<[^>]+>/g,''))+'">Taisyti</button></li>';}
  h+=row('dir','1. Kryptis',esc(d.title)+' <span class="counter-hint">('+esc(d.cat)+')</span>','dir');
  h+='<li class="grp">2. Poreikis</li>';
  d.qs.forEach(function(q){var t=ansText(q.id);h+=row(q.id,esc(q.id+'. '+q.title),t?esc(t):'<span class="muted">Neatsakyta – patikslinsime pokalbyje</span>',q.id);});
  h+='<li class="grp">3. Projektas ir kontaktai</li>';
  steps().filter(function(s){return s.stage===3&&s.qs;}).forEach(function(s){s.qs.forEach(function(q){var t=ansText(q.id);h+=row(q.id,esc(q.id+'. '+q.title),t?esc(t):'<span class="muted">—</span>',s.id);});});
  var c=state.contact;
  h+=row('contact','Kontaktai',esc(c.company)+', '+esc(c.name)+'<br>'+[c.email,c.phone].filter(Boolean).map(esc).join(' · ')+(c.comment?'<br>Komentaras: '+esc(c.comment):'')+'<br>Rinkodaros sutikimas: '+(c.marketing?'taip':'ne'),'contact');
  return h+'</ul><div class="info-box"><strong>Kas toliau?</strong> '+'Paspaudus „Siųsti užklausą“, ji bus išsiųsta adresu info@revision.lt, o jums – patvirtinimas el. paštu (jei jį nurodėte). Susisieksime per 24 val.</div>';
}
function render(focus){
  var s=cur();errSum.textContent='';
  var h='<h2 class="step-title" tabindex="-1" id="step-title">'+esc(s.title)+'</h2>'+(s.hint?'<p class="step-hint">'+esc(s.hint)+'</p>':'');
  if(s.dir)h+=dirHTML();else if(s.contact)h+=contactHTML();else if(s.summary)h+=summaryHTML();else h+=s.qs.map(function(q){return qHTML(q,s.qs.length===1);}).join('');
  host.innerHTML=h;btnBack.hidden=state.pos===0;
  btnNext.textContent=s.summary?'Siųsti užklausą':(state.returnToSummary?'Išsaugoti ir grįžti į peržiūrą':(s.contact?'Peržiūrėti užklausą →':'Toliau →'));
  renderAside();renderProgress();
  if(focus){document.getElementById('step-title').focus({preventScroll:true});var top=form.closest('.form-card').getBoundingClientRect().top+window.pageYOffset-90;window.scrollTo(0,Math.max(0,top));}
}
function setErr(name,msg){var el=document.getElementById(name+'-err');if(el)el.textContent=msg;}
function setFieldErr(id,msg){var el=document.getElementById('c-'+id+'-err'),i=document.getElementById('c-'+id);if(el)el.textContent=msg;if(i){if(msg)i.setAttribute('aria-invalid','true');else i.removeAttribute('aria-invalid');}}
function setDir(k){
  if(k===state.dir)return false;
  if(state.dir)dirObj(state.dir).qs.forEach(function(q){resetAns(q.id);});
  state.dir=k;
  var a=state.ans.B5,ok=b5opts().map(function(o){return o.l;});a.values=a.values.filter(function(v){return v===KITA||v===NEZ||ok.indexOf(v)>-1;});
  if(k==='konsultacija')resetAns('B1');
  return true;
}
host.addEventListener('change',function(e){
  var t=e.target;
  if(t.name==='dir'){var ch=setDir(t.value);setErr('dir','');if(ch)state.dirChanged=true;renderAside();renderProgress();return;}
  if(t.name&&state.ans[t.name]&&(t.type==='checkbox'||t.type==='radio')){
    var a=state.ans[t.name];
    if(t.type==='checkbox'&&t.checked){
      if(t.dataset.exclusive)host.querySelectorAll('input[name="'+t.name+'"]').forEach(function(x){if(x!==t)x.checked=false;});
      else host.querySelectorAll('input[name="'+t.name+'"][data-exclusive]').forEach(function(x){x.checked=false;});
    }
    setErr(t.name,'');
    a.values=Array.prototype.map.call(host.querySelectorAll('input[name="'+t.name+'"]:checked'),function(x){return x.value;});
    var w=t.closest('fieldset').querySelector('.other-wrap'),show=a.values.indexOf(KITA)>-1;w.hidden=!show;
    if(!show)a.other=a.other; /* tekstas išlaikomas, bet nenaudojamas */
    if(show&&t.value===KITA&&t.checked)w.querySelector('input').focus();
  }
  if(t.id==='c-marketing')state.contact.marketing=t.checked;
});
host.addEventListener('input',function(e){
  var t=e.target;
  if(t.dataset.other){state.ans[t.dataset.other].other=t.value;if(t.value.trim().length>=2){t.removeAttribute('aria-invalid');setErr(t.dataset.other,'');}}
  if(t.dataset.extra){state.ans[t.dataset.extra].extra[t.dataset.key]=t.value;}
  if(t.id&&t.id.indexOf('c-')===0&&t.id!=='c-marketing'){state.contact[t.name]=t.value;if(t.getAttribute('aria-invalid'))validateContactField(t.name);}
});
host.addEventListener('click',function(e){
  var b=e.target.closest('[data-edit]');if(!b)return;
  var all=steps();for(var i=0;i<all.length;i++)if(all[i].id===b.dataset.edit)state.pos=i;
  state.returnToSummary=true;state.dirChanged=false;render(true);
});
var EMAIL=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function phoneOk(v){var d=v.replace(/[\s\-().]/g,'');return /^(\+370|8)[3-9]\d{7}$/.test(d)||/^\+(?!370)\d{8,15}$/.test(d);}
function validateContactField(k){
  var c=state.contact,v=(c[k]||'').trim(),m='';
  if(k==='name'&&v.length<2)m='Įrašykite vardą ir pavardę.';
  if(k==='company'&&v.length<2)m='Įrašykite įmonės pavadinimą.';
  if(k==='email'&&v&&!EMAIL.test(v))m='Patikrinkite el. pašto adresą, pvz., vardas@imone.lt.';
  if(k==='phone'&&v&&!phoneOk(v))m='Patikrinkite numerį, pvz., +370 612 34567 arba 8 612 34567.';
  setFieldErr(k,m);return !m;
}
function validateStep(){
  var s=cur(),bad=[];
  if(s.summary)return true;
  if(s.dir){if(!state.dir){setErr('dir','Pasirinkite vieną kryptį.');bad.push(host.querySelector('input[name=dir]'));}}
  else if(s.contact){
    var c=state.contact;
    ['company','name','email','phone'].forEach(function(k){if(!validateContactField(k))bad.push(document.getElementById('c-'+k));});
    var e=c.email.trim(),p=c.phone.trim(),b6=state.ans.B6.values[0];setErr('either','');setErr('method','');
    if(!e&&!p){setErr('either','Nurodykite el. paštą arba telefoną – pakanka vieno.');bad.push(document.getElementById('c-email'));}
    else if(b6===SHARED[5].opts[1]&&!p){setErr('method','Pasirinkote „Susisiekti telefonu“ – nurodykite telefoną arba pakeiskite bendravimo būdą.');bad.push(document.getElementById('c-phone'));}
    else if(b6===SHARED[5].opts[0]&&!e){setErr('method','Pasirinkote pasiūlymą el. paštu – nurodykite el. paštą arba pakeiskite bendravimo būdą.');bad.push(document.getElementById('c-email'));}
  } else s.qs.forEach(function(q){
    var a=state.ans[q.id];
    if(q.req&&!a.values.length){setErr(q.id,q.multi?'Pažymėkite bent vieną variantą arba „Nežinau“.':'Pasirinkite variantą arba „Nežinau“.');bad.push(host.querySelector('input[name="'+q.id+'"]'));}
    else if(a.values.indexOf(KITA)>-1&&a.other.trim().length<2){var oi=document.getElementById(q.id+'-other');oi.setAttribute('aria-invalid','true');setErr(q.id,'Pasirinkote „Kita“ – įrašykite savo atsakymą.');bad.push(oi);}
  });
  if(bad.length){errSum.textContent=bad.length===1?'Patikrinkite pažymėtą lauką.':'Patikrinkite pažymėtus laukus ('+bad.length+').';bad[0].focus();return false;}
  return true;
}
form.addEventListener('submit',function(e){
  e.preventDefault();if(!validateStep())return;
  var s=cur(),all=steps();
  if(s.summary){finish();return;}
  if(state.returnToSummary&&!(s.dir&&state.dirChanged)){state.returnToSummary=false;state.pos=all.length-1;}
  else {if(s.dir&&state.dirChanged)state.returnToSummary=false;state.dirChanged=false;state.pos++;}
  render(true);
});
btnBack.addEventListener('click',function(){if(state.pos>0){state.pos--;state.returnToSummary=false;render(true);}});

/* Užklausos pateikimas el. paštu (mailto) */
var MAILTO='info@revision.lt',SUBJ='Užklausa iš svetainės';
function mailBody(){
  var d=dirObj(state.dir),c=state.contact,L=['Kryptis: '+d.title,''];
  d.qs.forEach(function(q){var t=ansText(q.id);if(t)L.push(q.id+'. '+q.title+'\n'+t);});
  steps().filter(function(s){return s.stage===3&&s.qs;}).forEach(function(s){s.qs.forEach(function(q){var t=ansText(q.id);if(t)L.push(q.id+'. '+q.title+'\n'+t);});});
  L.push('','Įmonė: '+c.company.trim(),'Vardas ir pavardė: '+c.name.trim());
  if(c.email.trim())L.push('El. paštas: '+c.email.trim());
  if(c.phone.trim())L.push('Telefonas: '+c.phone.trim());
  if(c.comment.trim())L.push('Komentaras: '+c.comment.trim());
  L.push('Sutinku gauti naujienas: '+(c.marketing?'taip':'ne'));
  return L.join('\n');
}
function mailHref(){return 'mailto:'+MAILTO+'?subject='+encodeURIComponent(SUBJ)+'&body='+encodeURIComponent(mailBody());}
var ENDPOINT='https://forma.revision.lt/send.php',T0=Date.now(),sending=false;
(function(){var hp=document.createElement('div');hp.setAttribute('aria-hidden','true');hp.style.cssText='position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden';
 hp.innerHTML='<label for="c-website">Svetainė (nepildykite)</label><input type="text" id="c-website" name="website" tabindex="-1" autocomplete="off">';form.appendChild(hp);})();
function showDone(html){
  form.hidden=true;document.querySelector('.form-note-box').hidden=true;document.querySelector('.progress-top').hidden=true;pBar.hidden=true;
  state.pos=steps().length;renderAside();done.hidden=false;done.innerHTML=html;
  document.getElementById('done-title').focus();var r=document.getElementById('restart');if(r)r.addEventListener('click',function(){location.href=location.pathname;});
}
function finishOk(conf){
  var p=conf==='sent'?'Patvirtinimą išsiuntėme į jūsų el. paštą. ':(conf==='failed'?'Patvirtinimo laiško į jūsų el. paštą išsiųsti nepavyko, bet užklausą gavome. ':'');
  showDone('<div class="confirm"><h2 tabindex="-1" id="done-title">Užklausa išsiųsta</h2>'+
   '<p role="status">Užklausa išsiųsta. '+p+'Susisieksime per 24 val.</p>'+
   '<p>Skubiai – <a href="tel:+37061553311">+370 615 53311</a> arba <a href="mailto:'+MAILTO+'">'+MAILTO+'</a>.</p>'+
   '<div class="cta-row"><button type="button" class="btn btn-outline" id="restart">Pildyti iš naujo</button></div></div>');
}
function finishFallback(){
  var href=mailHref();
  showDone('<div class="confirm"><h2 tabindex="-1" id="done-title">Užklausos išsiųsti nepavyko</h2>'+
   '<p role="alert"><strong>Užklausa neišsiųsta</strong> – nepavyko susisiekti su serveriu. Atidarėme jūsų el. pašto programą su paruoštu laišku adresu <a href="mailto:'+MAILTO+'">'+MAILTO+'</a> (tema „'+esc(SUBJ)+'“) – peržiūrėkite jį ir paspauskite „Siųsti“.</p>'+
   '<p>Gavę laišką, susisieksime per 24 val. Skubiai – <a href="tel:+37061553311">+370 615 53311</a>.</p>'+
   '<div class="note" style="margin:18px 0">El. pašto programa neatsidarė? Parašykite mums tiesiogiai <a href="mailto:'+MAILTO+'">'+MAILTO+'</a> arba paskambinkite.</div>'+
   '<div class="cta-row"><a class="btn btn-primary" id="mail-again" href="'+esc(href)+'">Atidaryti laišką</a><button type="button" class="btn btn-outline" id="restart">Pildyti iš naujo</button></div></div>');
  window.location.href=href;
}
function answersText(){var t=mailBody(),i=t.indexOf('\n\nĮmonė: ');t=i>-1?t.slice(0,i):t;return t.replace(/^Kryptis: [^\n]*\n\n?/,'');}
function finish(){
  if(sending)return;sending=true;
  var c=state.contact,hp=document.getElementById('c-website');
  var payload={direction:dirObj(state.dir).title,answers:answersText(),company:c.company.trim(),name:c.name.trim(),email:c.email.trim(),phone:c.phone.trim(),
   comment:(c.comment||'').trim(),marketing:!!c.marketing,website:hp?hp.value:'',elapsed:Math.round((Date.now()-T0)/1000)};
  btnNext.disabled=true;btnNext.textContent='Siunčiama…';errSum.textContent='';
  var ctl=window.AbortController?new AbortController():null,tm=setTimeout(function(){if(ctl)ctl.abort();},20000);
  fetch(ENDPOINT,{method:'POST',mode:'cors',credentials:'omit',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:ctl?ctl.signal:undefined})
  .then(function(r){return r.json().catch(function(){return {ok:false};}).then(function(j){return {status:r.status,j:j};});})
  .then(function(x){clearTimeout(tm);sending=false;
    if(x.j&&x.j.ok){finishOk(x.j.confirmation);return;}
    if(x.status===422){btnNext.disabled=false;btnNext.textContent='Siųsti užklausą';errSum.textContent='Serveris nepriėmė kai kurių duomenų – patikrinkite kontaktus (el. paštą, telefoną) ir bandykite dar kartą.';return;}
    if(x.status===429){btnNext.disabled=false;btnNext.textContent='Siųsti užklausą';errSum.textContent='Per trumpą laiką pateikta per daug užklausų. Parašykite mums tiesiogiai info@revision.lt arba paskambinkite +370 615 53311.';return;}
    if(x.status===400&&x.j&&x.j.error==='too_fast'){btnNext.disabled=false;btnNext.textContent='Siųsti užklausą';errSum.textContent='Palaukite kelias sekundes ir bandykite dar kartą.';return;}
    finishFallback();})
  .catch(function(){clearTimeout(tm);sending=false;finishFallback();});
}
/* Kryptis iš nuorodos ?kryptis=… */
var m=/[?&]kryptis=([a-z]+)/.exec(location.search);if(m&&dirObj(m[1])){setDir(m[1]);}
render(false);
})();
