// P4 užklausos modalas: tik krypties pasirinkimas. Nieko nesiunčia – „Tęsti“ atidaro esamą formą uzklausa.html?kryptis=…
(function(){
  var m=document.getElementById('p4-modal'); if(!m)return;
  var dlg=m.querySelector('.p4-dialog'), last=null, err=m.querySelector('.p4-merr');
  function focusables(){return Array.prototype.filter.call(dlg.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])'),function(e){return e.offsetParent!==null||e.type==='radio';});}
  function open(e,pre){
    if(e)e.preventDefault(); last=document.activeElement; m.hidden=false; document.body.classList.add('p4-lock');
    if(pre){var r=m.querySelector('input[value="'+pre+'"]'); if(r)r.checked=true;}
    var c=m.querySelector('input[name="p4dir"]:checked')||m.querySelector('input[name="p4dir"]'); (c||dlg).focus();
  }
  function close(){m.hidden=true;document.body.classList.remove('p4-lock');err.textContent='';if(last&&last.focus)last.focus();}
  document.addEventListener('click',function(e){
    var a=e.target.closest&&e.target.closest('[data-p4-modal]');
    if(a&&!e.ctrlKey&&!e.metaKey&&!e.shiftKey&&e.button===0){open(e,a.getAttribute('data-p4-modal'));}
  });
  m.addEventListener('click',function(e){if(e.target===m)close();});
  m.querySelector('.p4-x').addEventListener('click',close);
  m.addEventListener('keydown',function(e){
    if(e.key==='Escape'){e.preventDefault();close();return;}
    if(e.key!=='Tab')return;
    var f=focusables().filter(function(x){return x.type!=='radio'||x.checked||!m.querySelector('input[name="'+x.name+'"]:checked');});
    if(!f.length)return; var a=f[0],z=f[f.length-1];
    if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus();}
    else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus();}
  });
  m.querySelector('form').addEventListener('submit',function(e){
    e.preventDefault(); var c=m.querySelector('input[name="p4dir"]:checked');
    if(!c){err.textContent='Pasirinkite vieną kryptį.';m.querySelector('input[name="p4dir"]').focus();return;}
    var base=m.querySelector('form').getAttribute('action');
    location.href=base+'?kryptis='+encodeURIComponent(c.value);
  });
})();
